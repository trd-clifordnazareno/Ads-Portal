# UnZziper
It allows you to upload files without opening the Cpanel using PHP and JQuery

WELCOME TO UnZziper, By Shankhadeep Das


Sometimes, I face problems uploading my files through Cpanel. If the File size is big, then it becomes worse.
This is how I came up with this idea which allows me to upload files without opening my Cpanel.
Main feature of this upload handler is you can add this code snippet almost any where and it has its own visual uploader.
This uploaded uploads file in chuncks, you need not to worry about the file size.

Demo url: http://projects.computopedia.com/unziper/installer/

Description:
1. A fast way to upload your files to the server without opening your Cpanel.
2. Jquery file upload and PHP unzip;
3. Easy user interface.
4. No installation, unzip this file once and let it do the further UnZzip Works for you.
5. To access it on local machine just unzip it to **htdocs/your-folder-name** or **www/your-folder-name** folder and goto the address **http://localhost/your-folder-name/installer**
