<center>
<button ng-click="show()" class="btn btn-danger" style="/*margin-top:-40px;*/">Disapprove</button>
                                            <button ng-click="approve()" class="btn btn-success" style="/*margin-top:-40px;*/">approve</button>
                                            &nbsp&nbsp&nbsp<input type="checkbox" ng-click="toggleAll()" ng-model="isAllSelected" style="/*margin-left:39%;*/">Select all 
                                            <p style="/*margin-left:39%;*/">Please Close If You Want To Uncheck Many Photos</p></center>